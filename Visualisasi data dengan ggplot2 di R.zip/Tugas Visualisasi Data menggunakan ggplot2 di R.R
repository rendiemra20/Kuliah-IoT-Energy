# Install & Load Library
if (!require("tidyverse")) install.packages("tidyverse")
library(tidyverse)

# Load data
data <- read_csv("Steel_industry_data.csv")

# Cek struktur dan nama kolom
glimpse(data)

# Ubah kolom jadi factor biar urutan hari bener
data$Day_of_week <- factor(data$Day_of_week,
                           levels = c("Monday", "Tuesday", "Wednesday", "Thursday",
                                      "Friday", "Saturday", "Sunday"))

# Bikin data baru: rata-rata penggunaan kWh per hari
avg_usage <- data %>%
  group_by(Day_of_week) %>%
  summarise(Rata_rata_kWh = mean(Usage_kWh, na.rm = TRUE))

# Plot bar chart
ggplot(avg_usage, aes(x = Day_of_week, y = Rata_rata_kWh)) +
  geom_col(fill = "steelblue") +
  labs(
    title = "Rata-rata Penggunaan Energi (kWh) per Hari",
    x = "Hari",
    y = "Penggunaan Energi (kWh)"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

names(data)

